export const branding = {
  slogan: "Mommylicious Food, Served with Love!",
  navLinks: [
    "About",
    "Menu",
    "Gallery",
    "Zaika-E-Khaas",
    "Catering",
    "Mommylicious Mealbox",
    "Contact"
  ]
};
